export default async function handler(req, res) {
  res.send("تم تسجيل الدخول بنجاح (المعالجة الفعلية تأتي لاحقًا)");
}
